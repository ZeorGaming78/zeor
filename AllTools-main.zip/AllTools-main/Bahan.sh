pkg update -y
pkg upgarde -y
pkg install python -y
pkg install python2 -y
pkg install toilet -y
pkg install lolcat -y
pkg install cowsay -y
pkg install bash -y
pkg install mc -y
pkg install wget -y
pkg install jq -y
gem install lolcat -y
pkg install nano -y
pip install requste
pip install python

#Tambah Aja Sendiri
reset
cat *.txt
echo "[ Ketik : python *.py Untuk Menjalankan Scripy AllTools ]"
echo "INSTALL BAHAN SELESAI ATAU DONE !!!!!"
sleep 2

